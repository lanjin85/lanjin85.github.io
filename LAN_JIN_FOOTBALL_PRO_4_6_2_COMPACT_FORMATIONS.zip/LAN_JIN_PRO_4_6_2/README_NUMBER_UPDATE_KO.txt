LAN JIN PRO 4.4 — FIFA-inspired positional role numbering

Updated 2026-10-28

The default formation picker and all 36 tactics templates now assign position-based role numbers, instead of sequentially numbering players by creation order.

4-2-3-1:
GK: 1
Back line (top-to-bottom in the editor): 3, 5, 4, 2
Defensive midfielders: 6, 8
Attacking midfield: 11, 10, 7
Striker: 9

4-3-3:
GK: 1
Back line: 3, 5, 4, 2
Midfield: 6, 8, 10
Forwards: 11, 9, 7

14 formations supported, all 11 player role markers are unique within a team.
The same numbering changes apply to the opponent team's newly generated formations and 36 built-in tactical templates.

NOTES:
- This is a configurable coaching convention inspired by positional FIFA materials, NOT an official universal FIFA numbering rule or actual players' shirt numbers.
- Previously saved project files retain their old manual numbers until the formation/tactic is re-applied. Backup projects first.
- This release does not alter the existing AI tracking pipeline.
