import math
from app.engine import homography,map_point,metrics

def test_field_transform():
    h=homography([[100,100],[500,100],[500,300],[100,300]],[[0,0],[100,0],[100,50],[0,50]])
    assert math.dist(map_point(h,[300,200]),[50,25])<.01

def test_metrics_perfect():
    rows=[{'frame':i,'id':'1','x':i,'y':5} for i in range(3)]
    r=metrics(rows,rows)
    assert r['precision']==1 and r['recall']==1 and r['ID_switches']==0 and r['MOTA']==1

def test_metrics_id_swap():
    t=[{'frame':i,'id':'A','x':i,'y':5} for i in range(2)]
    p=[{'frame':0,'id':'1','x':0,'y':5},{'frame':1,'id':'2','x':1,'y':5}]
    assert metrics(p,t)['ID_switches']==1

def test_missing_detection():
    truth=[{'frame':i,'id':'A','x':1,'y':1} for i in range(3)]
    pred=[{'frame':0,'id':'1','x':1,'y':1}]
    assert metrics(pred,truth)['recall']==round(1/3,4)
