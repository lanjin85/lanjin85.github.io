from fastapi.testclient import TestClient
from app.server import app
client=TestClient(app)
def test_health_and_project():
    assert client.get('/health').status_code==200
    p=client.post('/api/projects').json()['id']
    assert client.put(f'/api/projects/{p}',json={'title':'Test'}).status_code==200
    assert client.get(f'/api/projects/{p}').json()['title']=='Test'
    assert client.post(f'/api/projects/{p}/calibrate',json={'image_points':[[10,10],[110,10],[110,60],[10,60]],'field_points':[[0,0],[100,0],[100,50],[0,50]]}).status_code==200
    assert client.get(f'/api/projects/{p}/export').status_code==200

def test_no_video_rejected():
    p=client.post('/api/projects').json()['id']
    assert client.post(f'/api/projects/{p}/analyze',json={}).status_code==400
    assert client.get(f'/api/projects/{p}/mapped').status_code==400
