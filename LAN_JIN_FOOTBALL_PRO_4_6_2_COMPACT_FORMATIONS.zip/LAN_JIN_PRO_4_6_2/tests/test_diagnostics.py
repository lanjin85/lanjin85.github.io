from app.engine import metrics

def test_idf1_consistent():
    a=[dict(frame=i,id=3,x=i,y=10) for i in range(5)]
    b=[dict(frame=i,id=77,x=i,y=10) for i in range(5)]
    r=metrics(a,b);assert r['IDF1']==1 and r['ID_switches']==0

def test_idf1_switch_penalty():
    a=[dict(frame=i,id=3 if i<3 else 8,x=i,y=10) for i in range(6)]
    b=[dict(frame=i,id=77,x=i,y=10) for i in range(6)]
    r=metrics(a,b);assert r['ID_switches']==1 and r['IDF1']<1

def test_occluded_frame_metric():
    a=[dict(frame=0,id=1,x=10,y=10)]
    b=[dict(frame=0,id=1,x=10,y=10,occluded='1'),dict(frame=1,id=1,x=10,y=10,occluded='1')]
    r=metrics(a,b);assert r['occluded_gt_count']==2 and r['occluded_frame_recall']==.5
