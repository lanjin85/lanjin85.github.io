from fastapi.testclient import TestClient
from app.server import app
import io,zipfile

def test_unified_project_zip_roundtrip():
    c=TestClient(app)
    pid=c.post('/api/projects').json()['id']
    tactics={'format':'LanJin-Football-Tactics-Studio','scenes':[{'name':'Press','objects':[]}],'objects':[]}
    assert c.put(f'/api/projects/{pid}/tactics',json=tactics).status_code==200
    z=c.get(f'/api/projects/{pid}/export').content
    assert 'tactics.json' in zipfile.ZipFile(io.BytesIO(z)).namelist()
    pid2=c.post('/api/import',files={'file':('project.zip',z,'application/zip')}).json()['id']
    assert c.get(f'/api/projects/{pid2}/tactics').json()==tactics
