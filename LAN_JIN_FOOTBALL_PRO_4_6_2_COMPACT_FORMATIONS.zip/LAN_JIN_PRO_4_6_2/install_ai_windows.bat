@echo off
cd /d "%~dp0"
if not exist .venv (echo Run start_windows.bat first. & pause & exit /b 1)
call .venv\Scripts\activate.bat
python -m pip install -r requirements-ai.txt
if errorlevel 1 (echo AI installation failed; see above. & pause & exit /b 1)
python -c "from ultralytics import YOLO; YOLO('yolo11n.pt'); print('Downloaded default model')"
pause
