@echo off
cd /d "%~dp0"
py -3.11 -V >nul 2>&1
if errorlevel 1 (echo Python 3.11 is not installed. Run python-3.11.9-amd64.exe first. & pause & exit /b 1)
if not exist .venv (py -3.11 -m venv .venv)
call .venv\Scripts\activate.bat
python -m pip install -r requirements.txt
if errorlevel 1 (echo Failed installing dependencies. & pause & exit /b 1)
start "" http://127.0.0.1:8765
python -m uvicorn app.server:app --host 127.0.0.1 --port 8765
pause
