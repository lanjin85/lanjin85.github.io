"""LAN JIN tracking engine. Optional Ultralytics, OpenCV required for actual video processing."""
import csv, json, math
from pathlib import Path
import cv2
import numpy as np

TRACKERS = {'botsort': 'botsort_reid.yaml', 'bytetrack': 'bytetrack.yaml'}

def homography(src, dst):
    a=np.asarray(src,dtype=np.float32);b=np.asarray(dst,dtype=np.float32)
    if a.shape != (4,2) or b.shape!=(4,2): raise ValueError('Four 2D source and destination points required')
    if cv2.contourArea(a)<20 or cv2.contourArea(b)<1: raise ValueError('Degenerate field quadrilateral')
    h=cv2.getPerspectiveTransform(a,b)
    if not np.isfinite(h).all(): raise ValueError('Invalid transform')
    return h

def map_point(h,pt):
    p=cv2.perspectiveTransform(np.array([[pt]],dtype=np.float32),h)[0,0]
    return [round(float(p[0]),3),round(float(p[1]),3)]

def metrics(pred, truth, max_distance=30):
    """Frame/ID-aware exact ID evaluation; annotated point errors, precision, recall and ID switches.
    Predictions CSV contain frame,id,x,y; truth same. Coordinates must share reference frame.
    Precision matching pairs by Euclidean distance regardless ID; ID switches across matches.
    """
    import scipy.optimize
    pf={}; gf={}
    for r in pred:pf.setdefault(int(r['frame']),[]).append(r)
    for r in truth:gf.setdefault(int(r['frame']),[]).append(r)
    tp=fp=fn=switches=0; dists=[]; associations={}; identity_matches={}; gt_counts={}; pred_counts={}; occluded_total=occluded_found=0; identity_matched=[]
    for frame in sorted(set(pf)|set(gf)):
        p=pf.get(frame,[]);g=gf.get(frame,[])
        for item in p:pred_counts[str(item['id'])]=pred_counts.get(str(item['id']),0)+1
        for item in g:
            gt_counts[str(item['id'])]=gt_counts.get(str(item['id']),0)+1
            if str(item.get('occluded','')).strip().lower() in ('1','true','yes'):occluded_total+=1
        if not p:fn+=len(g);continue
        if not g:fp+=len(p);continue
        cost=np.array([[math.hypot(float(x['x'])-float(y['x']),float(x['y'])-float(y['y'])) for y in g] for x in p]);
        rows,cols=scipy.optimize.linear_sum_assignment(cost)
        matched=[]
        for i,j in zip(rows,cols):
            if cost[i,j] <= max_distance:
                matched.append((i,j));tp+=1;dists.append(float(cost[i,j]));gid=str(g[j]['id']);pid=str(p[i]['id'])
                if gid in associations and associations[gid]!=pid:switches+=1
                associations[gid]=pid
                identity_matches[(gid,pid)]=identity_matches.get((gid,pid),0)+1
                if str(g[j].get('occluded','')).strip().lower() in ('1','true','yes'):occluded_found+=1
        fp+=len(p)-len(matched);fn+=len(g)-len(matched)
    precision=tp/(tp+fp) if tp+fp else 0
    recall=tp/(tp+fn) if tp+fn else 0
    mota=1-(fp+fn+switches)/max(1,tp+fn)
    gids=list(gt_counts);pids=list(pred_counts)
    idtp=0
    if gids and pids:
        matrix=np.array([[identity_matches.get((g,p),0) for p in pids] for g in gids],dtype=float)
        rr,cc=scipy.optimize.linear_sum_assignment(-matrix)
        idtp=int(sum(matrix[i,j] for i,j in zip(rr,cc)))
    idfp=sum(pred_counts.values())-idtp;idfn=sum(gt_counts.values())-idtp
    idf1=2*idtp/max(1,2*idtp+idfp+idfn)
    # Re-identification after occlusion requires GT occlusion segments and continuity.
    occlusion_note='occlusion flag absent in GT' if not any('occluded' in r for r in truth) else 'Frame-wise detection recall on GT flagged occluded frames; NOT recovery-after-occlusion accuracy.'
    return {'matching_radius':max_distance,'TP':tp,'FP':fp,'FN':fn,'ID_switches':switches,'precision':round(precision,4),'recall':round(recall,4),'F1':round(2*precision*recall/(precision+recall),4) if precision+recall else 0,'MOTA':round(mota,4),'mean_position_error':round(float(np.mean(dists)),3) if dists else None,'IDF1':round(idf1,4),'IDTP':idtp,'IDFP':idfp,'IDFN':idfn,'occluded_frame_recall':round(occluded_found/occluded_total,4) if occluded_total else None,'occluded_gt_count':occluded_total,'note':'IDF1 globally matches tracked IDs to GT IDs via frame-wise spatial matches. HOTA and true post-occlusion reidentification are not computed. '+occlusion_note}

def read_csv(path):
    with open(path,encoding='utf-8-sig',newline='') as f:
        reader=csv.DictReader(f)
        if not {'frame','id','x','y'}.issubset(reader.fieldnames or []): raise ValueError('CSV columns: frame,id,x,y')
        return list(reader)

def track_video(video, output, model_name='yolo11n.pt', tracker='botsort', use_reid=True, confidence=0.25, max_frames=0, progress=None):
    """Run real inference if installed. Output detections/tracks, frame-indexed, with footpoints.
    Do not imply ID stability equals identity ground truth. Keep non-person classes excluded.
    """
    try:from ultralytics import YOLO
    except ImportError as exc:raise RuntimeError('AI engine not installed. pip install -r requirements-ai.txt') from exc
    if tracker not in TRACKERS:raise ValueError('unsupported tracker')
    detector=YOLO(model_name)
    cap=cv2.VideoCapture(str(video))
    if not cap.isOpened():raise ValueError('Video cannot be opened')
    fps=float(cap.get(cv2.CAP_PROP_FPS)) or 25.0
    width=int(cap.get(cv2.CAP_PROP_FRAME_WIDTH));height=int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    total=int(cap.get(cv2.CAP_PROP_FRAME_COUNT)); out=Path(output);out.mkdir(parents=True,exist_ok=True)
    rows=[];frame_no=0
    yaml_path=str(Path(__file__).parent/'botsort_reid.yaml') if tracker=='botsort' and use_reid else ('botsort.yaml' if tracker=='botsort' else 'bytetrack.yaml')
    try:
        while True:
            ok,frame=cap.read()
            if not ok or (max_frames and frame_no>=max_frames):break
            results=detector.track(frame, persist=True, tracker=yaml_path, classes=[0], conf=confidence, verbose=False)
            for result in results:
                if result.boxes is None or result.boxes.id is None:continue
                boxes=result.boxes.xyxy.cpu().numpy(); ids=result.boxes.id.int().cpu().tolist();confs=result.boxes.conf.cpu().numpy()
                for box,tid,score in zip(boxes,ids,confs):
                    x1,y1,x2,y2=[float(v) for v in box]
                    rows.append({'frame':frame_no,'time':round(frame_no/fps,4),'id':tid,'x':round((x1+x2)/2,2),'y':round(y2,2),'x1':round(x1,2),'y1':round(y1,2),'x2':round(x2,2),'y2':round(y2,2),'confidence':round(float(score),4)})
            frame_no+=1
            if progress and frame_no%10==0:progress(frame_no,total)
    finally:cap.release()
    with open(out/'tracks.csv','w',encoding='utf-8',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=['frame','time','id','x','y','x1','y1','x2','y2','confidence']);writer.writeheader();writer.writerows(rows)
    meta={'fps':fps,'width':width,'height':height,'frames_processed':frame_no,'detections':len(rows),'tracker':tracker,'reid_requested':bool(use_reid and tracker=='botsort'),'model':model_name,'warning':'Tracker IDs are hypotheses, not verified player identities. Validate against manually annotated truth.'}
    (out/'run.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf8')
    return meta

def propagate_calibration(video, initial_points, every=10, max_frames=500):
    """Track homography from 1st frame to subsequent frames via ORB and RANSAC.
    A visual landmark tracker, NOT a semantic football pitch detector.
    Quality gating refuses weak camera homographies.
    """
    cap=cv2.VideoCapture(str(video));ok,first=cap.read()
    if not ok:raise ValueError('Cannot read first frame')
    base=cv2.cvtColor(first,cv2.COLOR_BGR2GRAY)
    orb=cv2.ORB_create(nfeatures=2200);basekp,des=orb.detectAndCompute(base,None)
    if des is None or len(basekp)<12:raise ValueError('Insufficient baseline image features')
    matcher=cv2.BFMatcher(cv2.NORM_HAMMING)
    results=[{'frame':0,'quality':'reference','points':initial_points,'inlier_ratio':1.0}]
    frame=0
    while frame<max_frames:
        ok,img=cap.read()
        if not ok:break
        frame+=1
        if frame%every:continue
        gray=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY);kp,d=orb.detectAndCompute(gray,None)
        if d is None or len(kp)<12:
            results.append({'frame':frame,'quality':'failed','reason':'not enough features'});continue
        pairs=matcher.knnMatch(des,d,k=2);good=[m for m,n in pairs if m.distance<0.72*n.distance]
        if len(good)<15:
            results.append({'frame':frame,'quality':'failed','reason':'not enough correspondences'});continue
        src=np.float32([basekp[m.queryIdx].pt for m in good]);dst=np.float32([kp[m.trainIdx].pt for m in good]);h,mask=cv2.findHomography(src,dst,cv2.RANSAC,4.0)
        ratio=float(mask.mean()) if mask is not None else 0
        if h is None or ratio<0.45:
            results.append({'frame':frame,'quality':'failed','inlier_ratio':round(ratio,3)});continue
        moved=cv2.perspectiveTransform(np.asarray(initial_points,dtype=np.float32).reshape(-1,1,2),h).reshape(-1,2)
        if not np.isfinite(moved).all():
            results.append({'frame':frame,'quality':'failed','reason':'invalid matrix'});continue
        results.append({'frame':frame,'quality':'estimated','points':moved.round(2).tolist(),'inlier_ratio':round(ratio,3)})
    cap.release()
    return results
