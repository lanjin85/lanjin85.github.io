"""Local-only professional editing/analysis workstation."""
import csv, json, shutil, uuid, zipfile, io
from pathlib import Path
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from .engine import homography, map_point, metrics, read_csv, track_video
ROOT=Path(__file__).resolve().parent.parent
DATA=ROOT/'workspaces'; DATA.mkdir(exist_ok=True)
app=FastAPI(title='Lan Jin Football Tactics PRO 4',version='4.0')
app.mount('/assets',StaticFiles(directory=ROOT/'app'),name='assets')

@app.get('/')
def home():return FileResponse(ROOT/'app'/'dashboard.html')
@app.get('/studio')
def studio():return FileResponse(ROOT/'app'/'studio.html')
@app.get('/health')
def health():
    try:import ultralytics;ai='available'
    except ImportError:ai='not installed'
    return {'status':'ok','ai_engine':ai,'project_dir':str(DATA)}

def workspace(pid):
    try:u=uuid.UUID(pid)
    except (ValueError,TypeError):raise HTTPException(400,'Invalid project ID')
    p=DATA/str(u)
    if not p.exists():raise HTTPException(404,'Project not found')
    return p

@app.post('/api/projects')
def new_project():
    pid=str(uuid.uuid4());p=DATA/pid;p.mkdir();(p/'project.json').write_text(json.dumps({'id':pid,'title':'New football project','notes':'','labels':{},'calibration':None,'timeline':[]},ensure_ascii=False),encoding='utf8');return {'id':pid}
@app.get('/api/projects/{pid}')
def get_project(pid:str):return json.loads((workspace(pid)/'project.json').read_text(encoding='utf8'))
@app.put('/api/projects/{pid}')
def update_project(pid:str,info:dict):
    p=workspace(pid);data=json.loads((p/'project.json').read_text(encoding='utf8'))
    for key in ('title','notes','labels','calibration','timeline','corrections'):
        if key in info:data[key]=info[key]
    (p/'project.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf8');return {'saved':True}
@app.put('/api/projects/{pid}/tactics')
def save_tactics(pid:str, data:dict):
    if data.get('format')!='LanJin-Football-Tactics-Studio':
        raise HTTPException(422,'Invalid tactics format')
    if len(json.dumps(data))>12_000_000:raise HTTPException(413,'Tactics payload too large')
    p=workspace(pid)
    (p/'tactics.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf8')
    return {'saved':True,'scenes':len(data.get('scenes',[]))}
@app.get('/api/projects/{pid}/tactics')
def read_tactics(pid:str):
    p=workspace(pid)/'tactics.json'
    if not p.exists():raise HTTPException(404,'No tactics saved for this project')
    return json.loads(p.read_text(encoding='utf8'))
@app.get('/api/projects/{pid}/evaluation')
def read_evaluation(pid:str):
    p=workspace(pid)/'evaluation.json'
    if not p.exists():raise HTTPException(404,'No evaluation completed')
    return json.loads(p.read_text())
@app.post('/api/projects/{pid}/video')
async def upload_video(pid:str, file:UploadFile=File(...)):
    p=workspace(pid); suffix=Path(file.filename or '').suffix.lower()
    if suffix not in {'.mp4','.mov','.mkv','.avi','.webm'}:raise HTTPException(400,'Unsupported video extension')
    target=p/('source'+suffix)
    with target.open('wb') as f:
        while chunk:=await file.read(1024*1024):f.write(chunk)
    return {'name':target.name,'bytes':target.stat().st_size}
@app.get('/api/projects/{pid}/video')
def get_video(pid:str):
    paths=list(workspace(pid).glob('source.*'))
    if not paths:raise HTTPException(404,'No video')
    return FileResponse(paths[0])
class Analyze(BaseModel):
    tracker:str='botsort';reid:bool=True;model:str='yolo11n.pt';max_frames:int=0
@app.post('/api/projects/{pid}/analyze')
def analyze(pid:str,options:Analyze):
    p=workspace(pid);files=list(p.glob('source.*'))
    if not files:raise HTTPException(400,'Upload a video first')
    if options.max_frames<0 or options.max_frames>200000:raise HTTPException(400,'Invalid frame count')
    if options.tracker not in ('botsort','bytetrack'):raise HTTPException(400,'Unknown tracker')
    # Models from local files or approved model alias only.
    if options.model not in ('yolo11n.pt','yolo11s.pt','yolo26n.pt','yolo26s.pt'):
        raise HTTPException(400,'Unsupported model selection')
    try:return track_video(files[0],p/'analysis',options.model,options.tracker,options.reid,max_frames=options.max_frames)
    except Exception as exc:raise HTTPException(422,str(exc))
@app.get('/api/projects/{pid}/tracks')
def tracks(pid:str):
    file=workspace(pid)/'analysis'/'tracks.csv'
    if not file.exists():raise HTTPException(404,'Run analysis first')
    return FileResponse(file,media_type='text/csv',filename='tracks.csv')
class Calibrate(BaseModel):
    image_points:list[list[float]]; field_points:list[list[float]]
@app.post('/api/projects/{pid}/calibrate')
def calibrate(pid:str,params:Calibrate):
    try:h=homography(params.image_points,params.field_points)
    except Exception as exc:raise HTTPException(422,str(exc))
    p=workspace(pid);data=json.loads((p/'project.json').read_text(encoding='utf8'))
    data['calibration']={'image_points':params.image_points,'field_points':params.field_points,'matrix':h.tolist()}
    (p/'project.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf8')
    return data['calibration']
@app.get('/api/projects/{pid}/mapped')
def mapped(pid:str):
    import numpy as np
    p=workspace(pid);meta=json.loads((p/'project.json').read_text(encoding='utf8'));cal=meta.get('calibration')
    if not cal:raise HTTPException(400,'Calibrate first')
    f=p/'analysis'/'tracks.csv'
    if not f.exists():raise HTTPException(400,'Analyze first')
    result=[]
    for row in read_csv(f):
        x,y=map_point(np.asarray(cal['matrix']),[float(row['x']),float(row['y'])]);result.append({**row,'field_x':x,'field_y':y})
    return {'tracks':result,'warning':'Use independent field-line landmarks for reprojection validation. Moving camera needs time-varying calibration.'}
@app.post('/api/projects/{pid}/evaluate')
async def evaluate(pid:str,truth:UploadFile=File(...),radius:float=30):
    if radius<=0:raise HTTPException(400,'radius must be positive')
    p=workspace(pid); pred=p/'analysis'/'tracks.csv'
    if not pred.exists():raise HTTPException(400,'Run analysis first')
    raw=await truth.read()
    try:
        gt=list(csv.DictReader(io.StringIO(raw.decode('utf-8-sig'))));result=metrics(read_csv(pred),gt,radius)
    except Exception as exc:raise HTTPException(422,str(exc))
    (p/'evaluation.json').write_text(json.dumps(result,indent=2),encoding='utf8');return result
@app.get('/api/projects/{pid}/export')
def export(pid:str):
    p=workspace(pid);output=p.parent/(pid+'.zip')
    with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED,allowZip64=True) as z:
        for f in p.rglob('*'):
            if f.is_file():z.write(f,arcname=f.relative_to(p))
    return FileResponse(output,media_type='application/zip',filename='LanJin_project_'+pid+'.zip')
@app.post('/api/import')
async def import_archive(file:UploadFile=File(...)):
    raw=await file.read()
    try:z=zipfile.ZipFile(io.BytesIO(raw));entries=z.infolist()
    except zipfile.BadZipFile:raise HTTPException(400,'Invalid ZIP')
    if sum(x.file_size for x in entries)>3_000_000_000:raise HTTPException(413,'Archive too large')
    pid=str(uuid.uuid4());p=DATA/pid;p.mkdir()
    for info in entries:
        rel=Path(info.filename)
        if rel.is_absolute() or '..' in rel.parts or info.is_dir():continue
        # import allowed dataset types only
        if rel.suffix.lower() not in ('.json','.csv','.mp4','.mov','.mkv','.avi','.webm'):continue
        target=p/rel;target.parent.mkdir(parents=True,exist_ok=True)
        with z.open(info) as source,target.open('wb') as dest:shutil.copyfileobj(source,dest)
    meta=p/'project.json'
    if not meta.exists():meta.write_text('{}')
    try:data=json.loads(meta.read_text(encoding='utf8'))
    except Exception:data={}
    data['id']=pid;meta.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf8')
    return {'id':pid}
@app.post('/api/projects/{pid}/camera-motion')
def camera_motion(pid:str,max_frames:int=500,every:int=10):
    from .engine import propagate_calibration
    p=workspace(pid);sources=list(p.glob('source.*'))
    meta=json.loads((p/'project.json').read_text(encoding='utf8'));cal=meta.get('calibration')
    if not sources or not cal:raise HTTPException(400,'Upload video and calibrate first frame')
    if not 1<=every<=1000 or not 1<=max_frames<=30000:raise HTTPException(400,'Invalid range')
    try:results=propagate_calibration(sources[0],cal['image_points'],every,max_frames)
    except Exception as exc:raise HTTPException(422,str(exc))
    (p/'camera_motion.json').write_text(json.dumps(results,indent=2),encoding='utf8')
    return {'processed_samples':len(results),'failed':sum(1 for x in results if x['quality']=='failed'),'samples':results,'warning':'ORB estimates image registration, not automatic football-line recognition. Recalibrate on failures and shot cuts.'}
