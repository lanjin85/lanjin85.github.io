# LAN JIN FOOTBALL TACTICS INTELLIGENCE PRO 4.0

**개인용 로컬 오픈 소스형 프로젝트 / 个人本地项目 / Personal locally hosted project**

## 설치 / 安装 / Install (Windows)
1. Install Python 3.11 or 3.12 (64-bit); select **Add Python to PATH**.
2. Double-click `start_windows.bat`. The first run installs Python packages and downloads YOLO weights when analysis is first started. Internet required initially.
3. Open `http://127.0.0.1:8765` in Chrome or Edge. The AI engine remains local to your machine; there is no cloud upload from this server.
4. Alternatively, in terminal: `py -m pip install -r requirements-ai.txt` then `py -m uvicorn app.server:app --host 127.0.0.1 --port 8765`.
5. **Without Python**, double-click `start_offline_windows.bat` for the older browser-only PRO 3 tactics studio, with reduced AI features.

## Workflow / 工作流程 / 작업 순서
1. Create project → upload your video → choose **BoT-SORT + ReID + GMC**. For a baseline without ReID use ByteTrack.
2. Analyze a short segment (e.g. 120 frames), inspect `tracks.csv`: frame, ID, footpoint (x,y), bounding rectangle and detection confidence.
3. Name verified player IDs manually in project label editor. The numeric tracking ID is not jersey number or verified identity.
4. Calibrate a visible **coplanar** field quadrilateral using the video and corresponding ground coordinates. Best results with known intersections of field lines, not arbitrarily chosen rectangle corners.
5. Optional camera-motion endpoint `/docs` → POST `/api/projects/{id}/camera-motion` propagates first-frame markers via ORB/RANSAC across sampled frames with quality flags. NOT semantic field-line automatic calibration. Fixed calibration should not be reused for moving footage.
6. Analyze accuracy: prepare independently annotated ground truth CSV with columns `frame,id,x,y` in **the same pixel coordinate system and frame indexing** as tracks.csv; upload under Evaluation, set match distance (pixels). Report precision, recall, F1, MOTA, ID switches, mean point error. True IDF1/HOTA/mAP not implemented.
7. Open `/studio` for trilingual 36-template tactical animation editor; its own project files remain in the PRO 3 format. Export both the backend project ZIP and the studio project ZIP to preserve every edit.
8. Use "Export complete ZIP" to archive video, track data, labels, evaluation data, calibration and notes in the Python project.

## Limits / 限制 / 제한
- YOLO and BoT-SORT inference require `ultralytics`, weight downloads, adequate CPU/GPU and compatible drivers. ReID is an optional tracker capability: **not a guarantee of permanent identity or jersey-number reading**. `model:auto` may fall back to a classification model.
- Moving-camera ORB/RANSAC estimates frame geometry from scene texture, not directly by detecting FIFA field lines. Zooms, scene cuts, fast pans and low-texture grass cause failure. Quality flags expose unreliable samples.
- Distances/speeds in meters are valid only after verified calibration of the right frame. Do not use these outputs for medical or professional officiating decisions without independent validation.
- Tracking scores are not pre-filled or fabricated. Annotated footage is necessary for scientific evaluation.
- Binary model weights are not bundled in the ZIP; download and pin them independently for long-term archival. Python/Ultralytics package dependencies need periodic security and compatibility reviews.
- Ultralytics software and model licenses may affect commercial distribution. Verify conditions at https://www.ultralytics.com/license before commercializing.
- The standalone browser editor (`/studio`) and analytics app (`/`) are distinct editable modules; the project ZIP export from `/` does **not** automatically include the separate editor's local browser files. Export both for complete backup.

## Backup / 备份 / 백업
Keep 3 copies: ZIP of this **source program**, exported **analysis project ZIP**, and exported **tactics editor project ZIP**. Store one on an external SSD and another in trusted storage. To restore on another PC install dependencies, run the server, then import the project ZIP. No claim that external software dependencies work indefinitely without maintenance.

## API documentation
After starting the server go to `http://127.0.0.1:8765/docs` (interactive endpoints for calibration and camera-motion). Accessible only on localhost when started as instructed.
