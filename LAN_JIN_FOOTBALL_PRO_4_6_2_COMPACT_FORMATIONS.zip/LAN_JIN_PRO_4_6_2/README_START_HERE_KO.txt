LAN JIN FOOTBALL TACTICS INTELLIGENCE PRO 4.1

1. Install the downloaded python-3.11.9-amd64.exe. CHECK Add python.exe to PATH.
2. Double-click start_windows.bat (internet required first time).
3. Open http://127.0.0.1:8765
4. Create new project, upload video, open tactical studio from top link.
5. In studio draw striped zones via space/zone tool, set hatch spacing.
6. Press Unified Save / Sync in studio. Go back to dashboard and Export complete ZIP.
7. On another PC install Python and restore the ZIP through dashboard import.
8. To add YOLO inference, run install_ai_windows.bat. The YOLO weights are downloaded from model provider; NOT original trained weights.
9. ReID requires compatible version and supported runtime. Verify GPU/CUDA setup and config before use.
10. Accuracy: annotate ground truth using CSV frame,id,x,y with footpoints. Only independent real-match ground truth produces real-match validity.

WARNING: Four-point camera projection needs manually entered known pitch geometry; ORB camera motion must be checked after cuts. Inferred player IDs are not guaranteed identities.
Keep ZIP projects and application source in two or more locations. Python/browser/AI dependencies need maintenance.

PRO 4.2 추가 기능:
- 실행 취소 및 다시 실행: Ctrl+Z / Ctrl+Y 또는 Ctrl+Shift+Z
- 추적된 선수 발밑 링 + 수직 빔, 빔 투명도, 궤적 표시 토글
- 추적 ID를 목록에서 선택 후 영상 발밑 클릭하여 수동 교정
- 프로젝트 ZIP에 추적 시각화 설정 포함
주의: 첨부된 것은 정지 이미지입니다. MP4 및 사람 손으로 라벨링한 참값 데이터가 없으므로 IDF1/MOTA 실영상 정확도는 검증되지 않았습니다.
